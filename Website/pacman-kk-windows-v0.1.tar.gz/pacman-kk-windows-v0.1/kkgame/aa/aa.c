#include<stdio.h>
#include<string.h>
#include<math.h>

char map_state[100][100];

int map_row,map_col,s1,s2;
void read_state();
void display_state();
void get_coordinates(int *row, int *col, char element);
int move_pacman(int pr,int pc);
int move_ghost(int ghost_row,int ghost_col);

int main()
{
	int ghosts[4],pacman;
	int i,pacmanRow,pacmanCol,ghostRow[4],ghostCol[4],opponentGhostRow[4],opponentGhostCol[4];
	
	read_state();
	/*coordinates of pacman and ghosts*/
	get_coordinates(&pacmanRow,&pacmanCol,'P');
	
	get_coordinates(ghostRow,ghostCol,'G');
	
	get_coordinates(opponentGhostRow,opponentGhostCol,'g');
		
	pacman=move_pacman(pacmanRow,pacmanCol);
	
	for(i=0;i<4;i++)
	{	
		ghosts[i]=0;
		if(ghostRow[i]!=-1||ghostCol[i]!=-1)
		{
			ghosts[i]=move_ghost(ghostRow[i],ghostCol[i]);
		}
	}
	printf("%d %d %d %d %d",ghosts[0],ghosts[1],ghosts[2],ghosts[3],pacman);
	return 0;
}

void read_state()
{
	int i,j;	
	scanf("%d",&map_row);
	scanf("%d",&map_col);
	for(i=0;i<map_row;i++)
	{	
		for(j=0;j<map_col;j++)
		{
			scanf("%c ",&map_state[i][j]); 
		}
	}
	scanf("%d",&s1);
	scanf("%d",&s2);
}
/*to get coordinates for characters*/
void get_coordinates(int *row, int *col, char element)
{
	int i,j;
	int ghost_count=0;
	*row=-1;*col=-1;
	for(i=0;i<4;i++)
	{
		row[i]=-1;col[i]=-1;
	}
	if(element!='P'&&element!='G'&&element!='g') {return;}
	if(element=='P')
	{
	for(i=0;i<map_row;i++)
	{
		for(j=0;j<map_col;j++)
		{
			if(map_state[i][j]==element)
				{
					*row=i;*col=j;
					return;	
				}		
		}
	}
		*row=-1;*col=-1;
	}
	else if (element=='G')
	{
		for (i=0;i<map_row;i++)
		{
			for(j=0;j<=map_col;j++)
			{
				if(map_state[i][j]=='A'||map_state[i][j]=='B'||map_state[i][j]=='C'||map_state[i][j]=='D')
				{
					row[map_state[i][j]-65]=i;
					col[map_state[i][j]-65]=j;
					ghost_count++;
					if(ghost_count==4) return;
					
				}		
			}
		}
	}	
	else if (element=='g')
	{
		for (i=0;i<map_row;i++)
		{
			for(j=0;j<=map_col;j++)
			{
				if(map_state[i][j]=='a'||map_state[i][j]=='b'||map_state[i][j]=='c'||map_state[i][j]=='d')
				{
					row[map_state[i][j]-65]=i;
					col[map_state[i][j]-65]=j;
					ghost_count++;
					if(ghost_count==4) return;
					
				}		
			}
		}
	}	
	


}
/*Return the move for pacman*/
int move_pacman(int pr,int pc)
{
	int pleft_row,pleft_col,pright_row,pright_col,pup_col,pup_row,pdown_row,pdown_col;

	pleft_row=pr;
	pleft_col=pc-1;

	pright_row=pr;
	pright_col=pc+1;
		
	pup_row=pr-1;
	pup_col=pc;

	pdown_row=pr+1;
	pdown_col=pc;
	

	if(map_state[pleft_row][pleft_col]!='W'&&
		map_state[pleft_row][pleft_col]!='A'&&
		map_state[pleft_row][pleft_col]!='B'&&
		map_state[pleft_row][pleft_col]!='C'&&
		map_state[pleft_row][pleft_col]!='D'&&
		map_state[pleft_row][pleft_col]!='a'&&
		map_state[pleft_row][pleft_col]!='b'&&
		map_state[pleft_row][pleft_col]!='c'&&
		map_state[pleft_row][pleft_col]!='d')
			
			return 3;

	else if(map_state[pright_row][pright_col]!='W'&&
			map_state[pright_row][pright_col]!='A'&&
			map_state[pright_row][pright_col]!='B'&&
			map_state[pright_row][pright_col]!='C'&&
			map_state[pright_row][pright_col]!='D'&&
			map_state[pright_row][pright_col]!='a'&&
			map_state[pright_row][pright_col]!='b'&&
			map_state[pright_row][pright_col]!='c'&&
			map_state[pright_row][pright_col]!='d')
		
				return 4;

	else if(map_state[pup_row][pup_col]!='W'&&
			map_state[pup_row][pup_col]!='A'&&
			map_state[pup_row][pup_col]!='B'&&
			map_state[pup_row][pup_col]!='C'&&
			map_state[pup_row][pup_col]!='D'&&
			map_state[pup_row][pup_col]!='a'&&
			map_state[pup_row][pup_col]!='b'&&
			map_state[pup_row][pup_col]!='c'&&
			map_state[pup_row][pup_col]!='d')

				return 1;

	else 
		return 2;
	
}

/*Return the move for ghots*/
int move_ghost(int ghost_row,int ghost_col)
{
	
	int gleft_row, gleft_col,gright_row,gright_col,gup_row, gup_col, gdown_row, gdown_col;
	float left_dis=-1,right_dis=-1,up_dis=-1,down_dis=-1;

	gleft_row=ghost_row;
	gleft_col=ghost_col-1;
	
	gright_row=ghost_row;
	gright_col=ghost_col+1;
	
	gup_row=ghost_row-1;
	gup_col=ghost_col;

	gdown_row=ghost_row+1;
	gdown_col=ghost_col;



	if(map_state[gright_row][gright_col]!='P'&&
		map_state[gright_row][gright_col]!='W'&&
		map_state[gright_row][gright_col]!='A'&&
		map_state[gright_row][gright_col]!='B'&&
		map_state[gright_row][gright_col]!='C'&&
		map_state[gright_row][gright_col]!='D')
		return 4;

	else if(map_state[gleft_row][gleft_col]!='P'&&
		map_state[gleft_row][gleft_col]!='W'&&
		map_state[gleft_row][gleft_col]!='A'&&
		map_state[gleft_row][gleft_col]!='B'&&
		map_state[gleft_row][gleft_col]!='C'&&
		map_state[gleft_row][gleft_col]!='D')
		return 3;


	else if(
		map_state[gup_row][gup_col]!='P'&&
		map_state[gup_row][gup_col]!='W'&&
		map_state[gup_row][gup_col]!='A'&&
		map_state[gup_row][gup_col]!='B'&&
		map_state[gup_row][gup_col]!='C'&&
		map_state[gup_row][gup_col]!='D')
		return 1;

	else 
		return 2;

	
}

